// Minecraft Texture Renamer Pro
// Improved C++ WinAPI GUI Application for modders
// Features:
// - Multilingual UI
// - Drag & drop folders into edit boxes
// - Recursive file counting
// - Safe two-phase rename to avoid collisions
// - Better RTL handling for Arabic
// - Clearer errors and cleaner structure

#pragma comment(linker,"\"/manifestdependency:type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")

#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#include <shellapi.h>
#include <filesystem>
#include <vector>
#include <string>
#include <algorithm>
#include <map>

namespace fs = std::filesystem;

enum class Language {
    Arabic, English, Japanese, German, French, Spanish, Chinese, Korean, Russian, Italian,
    Portuguese, Turkish, Dutch, Polish, Swedish, Indonesian, Vietnamese, Thai, Hindi, Ukrainian,
    Count
};

struct LanguagePack {
    std::wstring originalFolderLbl;
    std::wstring aiFolderLbl;
    std::wstring browseBtn;
    std::wstring startBtn;
    std::wstring swapBtn;
    std::wstring openFolderBtn;
    std::wstring statusReady;
    std::wstring statusSuccess;
    std::wstring statusError;
    std::wstring errSelectFirst;
    std::wstring errMismatch;
    std::wstring errTitle;
    std::wstring successTitle;
    std::wstring successMsg;
    std::wstring filesCountLbl;
};

static std::map<Language, LanguagePack> g_langDatabase = {
    { Language::Arabic, { L"الفولدر الأصلي:", L"فولدر صور AI:", L"اختيار", L"ابدأ إعادة التسمية 🔥", L"تبديل ⇄", L"فتح الفولدر 📁", L"جاهز...", L"تم الانتهاء بنجاح!", L"حدث خطأ أثناء إعادة التسمية", L"اختر الفولدرات أولاً", L"عدد الملفات غير متساوي بين الفولدرين!\n\nالفولدر الأصلي: {0}\nفولدر الـ AI: {1}", L"خطأ", L"نجاح", L"تمت إعادة تسمية الملفات بنجاح! 🚀", L"الملفات: " } },
    { Language::English, { L"Original Folder:", L"AI Images Folder:", L"Browse", L"Start Renaming 🔥", L"Swap ⇄", L"Open Folder 📁", L"Ready...", L"Completed successfully!", L"An error occurred during renaming", L"Please select folders first", L"File count mismatch!\n\nOriginal: {0}\nAI Folder: {1}", L"Error", L"Success", L"Files renamed successfully! 🚀", L"Files: " } },
    { Language::Japanese, { L"元のフォルダ:", L"AI画像のフォルダ:", L"参照", L"名前変更を開始 🔥", L"入替 ⇄", L"フォルダを開く 📁", L"準備完了...", L"正常に完了しました！", L"エラーが発生しました", L"最初にフォルダを選択してください", L"ファイル数が一致しません！\n\n元: {0}\nAI: {1}", L"エラー", L"成功", L"名前変更が成功しました！ 🚀", L"ファイル数: " } },
    { Language::German, { L"Original-Ordner:", L"AI-Bilder-Ordner:", L"Durchsuchen", L"Umbenennen starten 🔥", L"Tauschen ⇄", L"Ordner öffnen 📁", L"Bereit...", L"Erfolgreich abgeschlossen!", L"Fehler beim Umbenennen", L"Ordner zuerst auswählen", L"Dateianzahl stimmt nicht überein!\n\nOriginal: {0}\nAI: {1}", L"Fehler", L"Erfolgreich", L"Dateien erfolgreich umbenannt! 🚀", L"Dateien: " } },
    { Language::French, { L"Dossier original:", L"Dossier images IA:", L"Parcourir", L"Démarrer le renommage 🔥", L"Inverser ⇄", L"Ouvrir le dossier 📁", L"Prêt...", L"Terminé avec succès!", L"Une erreur est survenue", L"Veuillez choisir les dossiers", L"Le nombre de fichiers ne correspond pas !\n\nOriginal: {0}\nIA: {1}", L"Erreur", L"Succès", L"Fichiers renommés avec succès ! 🚀", L"Fichiers: " } },
    { Language::Spanish, { L"Carpeta original:", L"Carpeta de imágenes AI:", L"Buscar", L"Iniciar renombrado 🔥", L"Intercambiar ⇄", L"Abrir carpeta 📁", L"Listo...", L"¡Completado con éxito!", L"Ocurrió un error al renombrar", L"Seleccione las carpetas primero", L"¡El número de archivos no coincide!\n\nOriginal: {0}\nAI: {1}", L"Error", L"Éxito", L"¡Archivos renombrados con éxito! 🚀", L"Archivos: " } },
    { Language::Chinese, { L"原始文件夹:", L"AI图片文件夹:", L"浏览", L"开始重命名 🔥", L"切换 ⇄", L"打开文件夹 📁", L"就绪...", L"成功完成！", L"重命名过程中出错", L"请先选择文件夹", L"文件数量不匹配！\n\n原始: {0}\nAI: {1}", L"错误", L"成功", L"文件重命名成功！ 🚀", L"文件数: " } },
    { Language::Korean, { L"원본 폴더:", L"AI 이미지 폴더:", L"찾아보기", L"이름 바꾸기 시작 🔥", L"교환 ⇄", L"폴더 열기 📁", L"준비됨...", L"성공적으로 완료되었습니다!", L"오류가 발생했습니다", L"폴더를 먼저 선택하세요", L"파일 개수가 일치하지 않습니다!\n\n원본: {0}\nAI: {1}", L"오류", L"성공", L"이름 바꾸기 성공! 🚀", L"파일: " } },
    { Language::Russian, { L"Оригинальная папка:", L"Папка с ИИ-изображениями:", L"Обзор", L"Начать переименование 🔥", L"Поменять ⇄", L"Открыть папку 📁", L"Готово...", L"Успешно завершено!", L"Произошла ошибка", L"Сначала выберите папки", L"Количество файлов не совпадает!\n\nОригинал: {0}\nAI: {1}", L"Ошибка", L"Успех", L"Файлы успешно переименованы! 🚀", L"Файлы: " } },
    { Language::Italian, { L"Cartella originale:", L"Cartella immagini AI:", L"Sfoglia", L"Inizia a rinominare 🔥", L"Scambia ⇄", L"Apri cartella 📁", L"Pronto...", L"Completato con successo!", L"Errore durante la rinomina", L"Seleziona prima le cartelle", L"Il numero di file non coincide!\n\nOriginale: {0}\nAI: {1}", L"Errore", L"Successo", L"File rinominati con successo! 🚀", L"File: " } },
    { Language::Portuguese, { L"Pasta original:", L"Pasta de imagens AI:", L"Procurar", L"Iniciar renomeação 🔥", L"Alternar ⇄", L"Abrir pasta 📁", L"Pronto...", L"Concluído com sucesso!", L"Erro ao renomear", L"Selecione as pastas primeiro", L"O número de arquivos não coincide!\n\nOriginal: {0}\nAI: {1}", L"Erro", L"Sucesso", L"Arquivos renomeados com sucesso! 🚀", L"Arquivos: " } },
    { Language::Turkish, { L"Orijinal klasör:", L"AI resimleri klasörü:", L"Gözat", L"Yeniden adlandır 🔥", L"Değiştir ⇄", L"Klasörü aç 📁", L"Hazır...", L"Başarıyla tamamlandı!", L"Hata oluştu", L"Lütfen önce klasörleri seçin", L"Dosya sayıları eşleşmiyor!\n\nOrijinal: {0}\nAI: {1}", L"Hata", L"Başarılı", L"Dosyalar başarıyla adlandırıldı! 🚀", L"Dosyalar: " } },
    { Language::Dutch, { L"Originele map:", L"AI-afbeeldingenmap:", L"Bladeren", L"Start hernoemen 🔥", L"Wisselen ⇄", L"Map openen 📁", L"Gereed...", L"Succesvol afgerond!", L"Fout bij hernoemen", L"Selecteer eerst mappen", L"Aantal bestanden komt niet overeen!\n\nOrigineel: {0}\nAI: {1}", L"Fout", L"Succes", L"Bestanden succesvol hernoemd! 🚀", L"Bestanden: " } },
    { Language::Polish, { L"Oryginalny folder:", L"Folder obrazów AI:", L"Przeglądaj", L"Rozpocznij zmianę nazw 🔥", L"Zamień ⇄", L"Otwórz folder 📁", L"Gotowy...", L"Zakończono sukcesem!", L"Wystąpił błąd", L"Wybierz najpierw foldery", L"Liczba plików się nie zgadza!\n\nOryginalny: {0}\nAI: {1}", L"Błąd", L"Sukces", L"Nazwy plików zmienione! 🚀", L"Pliki: " } },
    { Language::Swedish, { L"Originalmapp:", L"AI-bildmapp:", L"Bläddra", L"Starta namnbyte 🔥", L"Byt plats ⇄", L"Öppna mapp 📁", L"Redo...", L"Klart!", L"Ett fel uppstod", L"Välj mappar först", L"Antalet filer matchar inte!\n\nOriginal: {0}\nAI: {1}", L"Fel", L"Succé", L"Namnbytet lyckades! 🚀", L"Filer: " } },
    { Language::Indonesian, { L"Folder asli:", L"Folder gambar AI:", L"Cari", L"Mulai ubah nama 🔥", L"Tukar ⇄", L"Buka folder 📁", L"Siap...", L"Selesai sukses!", L"Terjadi kesalahan", L"Pilih folder terlebih dahulu", L"Jumlah file tidak sama!\n\nAsli: {0}\nAI: {1}", L"Gagal", L"Sukses", L"Berhasil mengubah nama file! 🚀", L"File: " } },
    { Language::Vietnamese, { L"Thư mục gốc:", L"Thư mục ảnh AI:", L"Duyệt", L"Bắt đầu đổi tên 🔥", L"Chuyển đổi ⇄", L"Mở thư mục 📁", L"Sẵn sàng...", L"Hoàn thành xuất sắc!", L"Đã xảy ra lỗi", L"Vui lòng chọn thư mục trước", L"Số lượng tệp không khớp!\n\nGốc: {0}\nAI: {1}", L"Lỗi", L"Thành công", L"Đổi tên tệp thành công! 🚀", L"Tệp: " } },
    { Language::Thai, { L"โฟลเดอร์ต้นฉบับ:", L"โฟลเดอร์รูปภาพ AI:", L"เรียกดู", L"เริ่มเปลี่ยนชื่อ 🔥", L"สลับ ⇄", L"เปิดโฟลเดอร์ 📁", L"พร้อม...", L"เสร็จสิ้นสำเร็จ!", L"เกิดข้อผิดพลาด", L"กรุณาเลือกโฟลเดอร์ก่อน", L"จำนวนไฟล์ไม่ตรงกัน!\n\nต้นฉบับ: {0}\nAI: {1}", L"ข้อผิดพลาด", L"สำเร็จ", L"เปลี่ยนชื่อไฟล์สำเร็จ! 🚀", L"ไฟล์: " } },
    { Language::Hindi, { L"मूल फ़ोल्डर:", L"एआई इमेज फ़ोल्डर:", L"ब्राउज़ करें", L"नाम बदलना शुरू करें 🔥", L"बदलें ⇄", L"फ़ोल्डर खोलें 📁", L"तैयार...", L"सफलतापूर्वक पूरा हुआ!", L"त्रुटि हुई", L"पहले फ़ोल्डर चुनें", L"फ़ाइलों की संख्या समान नहीं है!\n\nमूल: {0}\nAI: {1}", L"त्रुटि", L"सफलता", L"नाम सफलतापूर्वक बदले गए! 🚀", L"फ़ाइलें: " } },
    { Language::Ukrainian, { L"Оригінальна папка:", L"Папка з ШІ-зображеннями:", L"Огляд", L"Почати перейменування 🔥", L"Поміняти ⇄", L"Відкрити папку 📁", L"Готово...", L"Успішно завершено!", L"Сталася помилка", L"Спочатку виберіть папки", L"Кількість файлів не збігається!\n\nОригінал: {0}\nAI: {1}", L"Помилка", L"Успіх", L"Файли успішно перейменовано! 🚀", L"Файли: " } }
};

static const wchar_t* g_langNames[] = {
    L"العربية", L"English", L"日本語", L"Deutsch", L"Français", L"Español", L"简体中文", L"한국어", L"Русский", L"Italiano",
    L"Português", L"Türkçe", L"Nederlands", L"Polski", L"Svenska", L"Bahasa Indonesia", L"Tiếng Việt", L"ไทย", L"हिन्दी", L"Українська"
};

static Language g_currentLanguage = Language::Arabic;

#define ID_BTN_ORIGINAL   1
#define ID_BTN_TARGET     2
#define ID_BTN_RENAME     3
#define ID_BTN_SWAP       4
#define ID_BTN_OPEN_DIR   5
#define ID_COMBO_LANG     6

static HWND hOriginalEdit = nullptr, hTargetEdit = nullptr, hStatus = nullptr, hLangCombo = nullptr;
static HWND hLblOrig = nullptr, hLblTarget = nullptr, hBtnOrig = nullptr, hBtnTarget = nullptr, hBtnRename = nullptr, hBtnSwap = nullptr, hBtnOpen = nullptr, hCountOrig = nullptr, hCountTarget = nullptr;
static std::wstring g_originalFolder;
static std::wstring g_targetFolder;
static HFONT g_guiFont = nullptr;

static WNDPROC g_oldOriginalEditProc = nullptr;
static WNDPROC g_oldTargetEditProc = nullptr;

static const LanguagePack& GetPack()
{
    return g_langDatabase.at(g_currentLanguage);
}

static void SetWindowTextSafe(HWND hwnd, const std::wstring& text)
{
    SetWindowTextW(hwnd, text.c_str());
}

static std::wstring GetEditText(HWND hwnd)
{
    int len = GetWindowTextLengthW(hwnd);
    if (len <= 0) return L"";
    std::wstring text;
    text.resize(static_cast<size_t>(len) + 1);
    GetWindowTextW(hwnd, text.data(), len + 1);
    text.resize(static_cast<size_t>(len));
    return text;
}

static std::vector<fs::path> GetFiles(const std::wstring& folder)
{
    std::vector<fs::path> files;
    if (folder.empty() || !fs::exists(folder)) return files;

    try {
        fs::directory_options opts = fs::directory_options::skip_permission_denied;
        for (const auto& entry : fs::recursive_directory_iterator(folder, opts))
        {
            if (entry.is_regular_file())
                files.push_back(entry.path());
        }
        std::sort(files.begin(), files.end());
    }
    catch (...) {
    }
    return files;
}

static std::wstring ReplaceTokens(std::wstring text, size_t origCount, size_t targetCount)
{
    const std::wstring a = std::to_wstring(origCount);
    const std::wstring b = std::to_wstring(targetCount);

    size_t pos = text.find(L"{0}");
    if (pos != std::wstring::npos) text.replace(pos, 3, a);
    pos = text.find(L"{1}");
    if (pos != std::wstring::npos) text.replace(pos, 3, b);
    return text;
}

static void SetStatus(const std::wstring& text)
{
    SetWindowTextW(hStatus, text.c_str());
}

static void UpdateFileCounts()
{
    const auto& pack = GetPack();

    g_originalFolder = GetEditText(hOriginalEdit);
    g_targetFolder = GetEditText(hTargetEdit);

    if (!g_originalFolder.empty() && fs::exists(g_originalFolder)) {
        const auto files = GetFiles(g_originalFolder);
        SetWindowTextW(hCountOrig, (pack.filesCountLbl + std::to_wstring(files.size())).c_str());
    }
    else {
        SetWindowTextW(hCountOrig, L"");
    }

    if (!g_targetFolder.empty() && fs::exists(g_targetFolder)) {
        const auto files = GetFiles(g_targetFolder);
        SetWindowTextW(hCountTarget, (pack.filesCountLbl + std::to_wstring(files.size())).c_str());
    }
    else {
        SetWindowTextW(hCountTarget, L"");
    }
}

static std::wstring SelectFolder(HWND hwndOwner)
{
    BROWSEINFOW bi{};
    bi.hwndOwner = hwndOwner;
    bi.lpszTitle = GetPack().originalFolderLbl.c_str();
    bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;

    LPITEMIDLIST pidl = SHBrowseForFolderW(&bi);
    if (!pidl) return L"";

    wchar_t path[MAX_PATH]{};
    std::wstring result;
    if (SHGetPathFromIDListW(pidl, path))
        result = path;

    CoTaskMemFree(pidl);
    return result;
}

static void ApplyLanguageToWindow(HWND hwnd)
{
    const auto& pack = GetPack();

    SetWindowTextW(hLblOrig, pack.originalFolderLbl.c_str());
    SetWindowTextW(hLblTarget, pack.aiFolderLbl.c_str());
    SetWindowTextW(hBtnOrig, pack.browseBtn.c_str());
    SetWindowTextW(hBtnTarget, pack.browseBtn.c_str());
    SetWindowTextW(hBtnRename, pack.startBtn.c_str());
    SetWindowTextW(hBtnSwap, pack.swapBtn.c_str());
    SetWindowTextW(hBtnOpen, pack.openFolderBtn.c_str());
    SetWindowTextW(hStatus, pack.statusReady.c_str());

    LONG_PTR exStyle = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
    exStyle &= ~(WS_EX_LAYOUTRTL | WS_EX_RTLREADING);
    if (g_currentLanguage == Language::Arabic) {
        exStyle |= WS_EX_LAYOUTRTL | WS_EX_RTLREADING;
    }
    SetWindowLongPtrW(hwnd, GWL_EXSTYLE, exStyle);

    SetWindowTextW(hwnd, L"Minecraft Texture Renamer Pro");
    UpdateFileCounts();
    InvalidateRect(hwnd, nullptr, TRUE);
}

static void RenameTextures()
{
    const auto& pack = GetPack();

    g_originalFolder = GetEditText(hOriginalEdit);
    g_targetFolder = GetEditText(hTargetEdit);

    if (g_originalFolder.empty() || g_targetFolder.empty()) {
        MessageBoxW(nullptr, pack.errSelectFirst.c_str(), pack.errTitle.c_str(), MB_ICONERROR);
        return;
    }

    if (!fs::exists(g_originalFolder) || !fs::exists(g_targetFolder)) {
        MessageBoxW(nullptr, pack.errSelectFirst.c_str(), pack.errTitle.c_str(), MB_ICONERROR);
        return;
    }

    const auto originalFiles = GetFiles(g_originalFolder);
    const auto targetFiles = GetFiles(g_targetFolder);

    if (originalFiles.empty() || targetFiles.empty()) {
        SetStatus(L"No files found.");
        return;
    }

    if (originalFiles.size() != targetFiles.size()) {
        const std::wstring msg = ReplaceTokens(pack.errMismatch, originalFiles.size(), targetFiles.size());
        MessageBoxW(nullptr, msg.c_str(), pack.errTitle.c_str(), MB_ICONERROR);
        return;
    }

    try {
        std::vector<fs::path> tempPaths;
        tempPaths.reserve(targetFiles.size());

        const ULONGLONG stamp = GetTickCount64();

        for (size_t i = 0; i < targetFiles.size(); ++i) {
            const fs::path& src = targetFiles[i];
            std::wstring tempName = L".trp_tmp_" + std::to_wstring(stamp) + L"_" + std::to_wstring(i) + src.extension().wstring();
            fs::path tempPath = src.parent_path() / tempName;

            if (fs::exists(tempPath)) {
                fs::remove(tempPath);
            }

            fs::rename(src, tempPath);
            tempPaths.push_back(tempPath);
        }

        for (size_t i = 0; i < tempPaths.size(); ++i) {
            const std::wstring originalStem = originalFiles[i].stem().wstring();
            const std::wstring ext = tempPaths[i].extension().wstring();
            fs::path finalPath = tempPaths[i].parent_path() / (originalStem + ext);

            if (fs::exists(finalPath)) {
                fs::remove(finalPath);
            }

            fs::rename(tempPaths[i], finalPath);
        }

        MessageBoxW(nullptr, pack.successMsg.c_str(), pack.successTitle.c_str(), MB_ICONINFORMATION);
        SetStatus(pack.statusSuccess);
        UpdateFileCounts();
    }
    catch (const fs::filesystem_error&) {
        MessageBoxW(nullptr, pack.statusError.c_str(), pack.errTitle.c_str(), MB_ICONERROR);
        SetStatus(pack.statusError);
    }
    catch (...) {
        MessageBoxW(nullptr, pack.statusError.c_str(), pack.errTitle.c_str(), MB_ICONERROR);
        SetStatus(pack.statusError);
    }
}

static void SetControlFont(HWND hwnd, HFONT font)
{
    SendMessageW(hwnd, WM_SETFONT, (WPARAM)font, TRUE);
}

static LRESULT CALLBACK EditSubclassProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (uMsg == WM_DROPFILES) {
        HDROP hDrop = (HDROP)wParam;
        wchar_t droppedPath[MAX_PATH]{};

        if (DragQueryFileW(hDrop, 0, droppedPath, MAX_PATH)) {
            if (fs::is_directory(droppedPath)) {
                SetWindowTextW(hwnd, droppedPath);
                UpdateFileCounts();
            }
        }

        DragFinish(hDrop);
        return 0;
    }

    WNDPROC oldProc = (hwnd == hOriginalEdit) ? g_oldOriginalEditProc : g_oldTargetEditProc;
    return CallWindowProcW(oldProc, hwnd, uMsg, wParam, lParam);
}

static LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_CREATE:
    {
        g_guiFont = CreateFontW(
            16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI"
        );

        hLblOrig = CreateWindowW(L"STATIC", L"", WS_VISIBLE | WS_CHILD, 20, 20, 170, 20, hwnd, nullptr, nullptr, nullptr);
        hOriginalEdit = CreateWindowW(L"EDIT", L"", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL, 20, 45, 330, 25, hwnd, nullptr, nullptr, nullptr);
        hBtnOrig = CreateWindowW(L"BUTTON", L"", WS_VISIBLE | WS_CHILD, 360, 45, 80, 25, hwnd, (HMENU)ID_BTN_ORIGINAL, nullptr, nullptr);
        hCountOrig = CreateWindowW(L"STATIC", L"", WS_VISIBLE | WS_CHILD, 450, 48, 120, 20, hwnd, nullptr, nullptr, nullptr);

        hBtnSwap = CreateWindowW(L"BUTTON", L"", WS_VISIBLE | WS_CHILD, 190, 80, 100, 25, hwnd, (HMENU)ID_BTN_SWAP, nullptr, nullptr);

        hLblTarget = CreateWindowW(L"STATIC", L"", WS_VISIBLE | WS_CHILD, 20, 110, 170, 20, hwnd, nullptr, nullptr, nullptr);
        hTargetEdit = CreateWindowW(L"EDIT", L"", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL, 20, 135, 330, 25, hwnd, nullptr, nullptr, nullptr);
        hBtnTarget = CreateWindowW(L"BUTTON", L"", WS_VISIBLE | WS_CHILD, 360, 135, 80, 25, hwnd, (HMENU)ID_BTN_TARGET, nullptr, nullptr);
        hCountTarget = CreateWindowW(L"STATIC", L"", WS_VISIBLE | WS_CHILD, 450, 138, 120, 20, hwnd, nullptr, nullptr, nullptr);

        hBtnRename = CreateWindowW(L"BUTTON", L"", WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON, 20, 180, 200, 40, hwnd, (HMENU)ID_BTN_RENAME, nullptr, nullptr);
        hBtnOpen = CreateWindowW(L"BUTTON", L"", WS_VISIBLE | WS_CHILD, 230, 180, 150, 40, hwnd, (HMENU)ID_BTN_OPEN_DIR, nullptr, nullptr);

        hLangCombo = CreateWindowW(L"COMBOBOX", L"", WS_VISIBLE | WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL, 395, 187, 140, 200, hwnd, (HMENU)ID_COMBO_LANG, nullptr, nullptr);

        hStatus = CreateWindowW(L"STATIC", L"", WS_VISIBLE | WS_CHILD | SS_SUNKEN, 20, 240, 515, 25, hwnd, nullptr, nullptr, nullptr);

        DragAcceptFiles(hOriginalEdit, TRUE);
        DragAcceptFiles(hTargetEdit, TRUE);

        g_oldOriginalEditProc = (WNDPROC)SetWindowLongPtrW(hOriginalEdit, GWLP_WNDPROC, (LONG_PTR)EditSubclassProc);
        g_oldTargetEditProc = (WNDPROC)SetWindowLongPtrW(hTargetEdit, GWLP_WNDPROC, (LONG_PTR)EditSubclassProc);

        for (int i = 0; i < 20; ++i)
            SendMessageW(hLangCombo, CB_ADDSTRING, 0, (LPARAM)g_langNames[i]);
        SendMessageW(hLangCombo, CB_SETCURSEL, (WPARAM)g_currentLanguage, 0);

        EnumChildWindows(hwnd, [](HWND child, LPARAM font) -> BOOL {
            SendMessageW(child, WM_SETFONT, font, TRUE);
            return TRUE;
        }, (LPARAM)g_guiFont);

        ApplyLanguageToWindow(hwnd);
        break;
    }

    case WM_COMMAND:
    {
        if (HIWORD(wParam) == EN_CHANGE && ((HWND)lParam == hOriginalEdit || (HWND)lParam == hTargetEdit)) {
            UpdateFileCounts();
        }

        switch (LOWORD(wParam))
        {
        case ID_BTN_ORIGINAL:
        {
            std::wstring folder = SelectFolder(hwnd);
            if (!folder.empty()) {
                SetWindowTextW(hOriginalEdit, folder.c_str());
                UpdateFileCounts();
            }
            break;
        }

        case ID_BTN_TARGET:
        {
            std::wstring folder = SelectFolder(hwnd);
            if (!folder.empty()) {
                SetWindowTextW(hTargetEdit, folder.c_str());
                UpdateFileCounts();
            }
            break;
        }

        case ID_BTN_SWAP:
        {
            const std::wstring tempOrig = GetEditText(hOriginalEdit);
            const std::wstring tempTarget = GetEditText(hTargetEdit);
            SetWindowTextW(hOriginalEdit, tempTarget.c_str());
            SetWindowTextW(hTargetEdit, tempOrig.c_str());
            UpdateFileCounts();
            break;
        }

        case ID_BTN_RENAME:
            RenameTextures();
            break;

        case ID_BTN_OPEN_DIR:
        {
            const std::wstring target = GetEditText(hTargetEdit);
            if (!target.empty() && fs::exists(target)) {
                ShellExecuteW(nullptr, L"open", target.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            }
            break;
        }

        case ID_COMBO_LANG:
            if (HIWORD(wParam) == CBN_SELCHANGE) {
                int index = (int)SendMessageW(hLangCombo, CB_GETCURSEL, 0, 0);
                if (index >= 0 && index < (int)Language::Count) {
                    g_currentLanguage = (Language)index;
                    ApplyLanguageToWindow(hwnd);
                }
            }
            break;
        }
        break;
    }

    case WM_DROPFILES:
    {
        HDROP hDrop = (HDROP)wParam;
        wchar_t droppedPath[MAX_PATH]{};

        if (DragQueryFileW(hDrop, 0, droppedPath, MAX_PATH)) {
            if (fs::is_directory(droppedPath)) {
                POINT pt{};
                DragQueryPoint(hDrop, &pt);

                HWND child = ChildWindowFromPointEx(hwnd, pt, CWP_SKIPINVISIBLE);
                if (child == hOriginalEdit || child == hTargetEdit) {
                    SetWindowTextW(child, droppedPath);
                    UpdateFileCounts();
                }
            }
        }

        DragFinish(hDrop);
        break;
    }

    case WM_DESTROY:
        if (g_guiFont) {
            DeleteObject(g_guiFont);
            g_guiFont = nullptr;
        }
        PostQuitMessage(0);
        break;
    }

    return DefWindowProcW(hwnd, uMsg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow)
{
    const wchar_t CLASS_NAME[] = L"TextureRenamerProClass";

    WNDCLASSW wc{};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    if (!RegisterClassW(&wc))
        return 0;

    HWND hwnd = CreateWindowExW(
        0,
        CLASS_NAME,
        L"Minecraft Texture Renamer Pro",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 580, 320,
        nullptr, nullptr, hInstance, nullptr
    );

    if (!hwnd)
        return 0;

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    MSG msg{};
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return (int)msg.wParam;
}
